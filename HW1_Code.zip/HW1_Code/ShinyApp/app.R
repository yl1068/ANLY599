# Import libraries
library(rsconnect)
rsconnect::setAccountInfo(name='yiranl', token='AEF99443F20E7DBB2179F71511C50E4D', secret='J76Y5EBGF0KcJ49cyVEOUtpnO6TZq1/Wy56BwQJD')
library(shiny)

library(data.table)

# Read in the RF model
model <- readRDS("HW1_model.rds")


####################################
# User interface                   #
####################################

ui <- pageWithSidebar(
  
  # Page header
  headerPanel('Student Admission Widget'),
  
  # Input values
  sidebarPanel(
    #HTML("<h3>Input parameters</h3>"),
    tags$label(h3('Student Information')),
    textInput("State",
              label="State",
              value=""),
    numericInput("GPA", 
                 label = "GPA", 
                 value = ""),
    numericInput("WorkExp", 
                 label = "Work Exp", 
                 value = ""),
    numericInput("TestScore", 
                 label = "Test Score", 
                 value = ""),
    
    numericInput("WritingScore", 
                 label = "Writing Score", 
                 value = ""),
    textInput("Gender", 
                 label = "Gender", 
                 value = ""),
    numericInput("VolunteerLevel", 
                 label = "VolunteerLevel", 
                 value = ""),
    
    actionButton("submitbutton", "Submit", 
                 class = "btn btn-primary")
  ),
  
  mainPanel(
    tags$label(h3('Status/Output')), # Status/Output Text Box
    verbatimTextOutput('contents'),
    tableOutput('tabledata') # Prediction results table
    
  )
)

####################################
# Server                           #
####################################

server<- function(input, output, session) {

  # Input Data
  datasetInput <- reactive({  
    
    df <- data.frame(
      Name = c(
               "GPA",
               "WorkExp",
               "TestScore",
               "WritingScore",
               "Gender",
               "VolunteerLevel"),
      Value = as.character(c(
                             input$GPA,
                             input$WorkExp,
                             input$TestScore,
                             input$WritingScore,
                             if(tolower(input$Gender)=='male') 0
                             else 1,
                             input$VolunteerLevel)),
      stringsAsFactors = FALSE)
    
    Species <- 0
    df <- rbind(df, Species)
    input <- transpose(df)
    write.table(input,"input.csv", sep=",", quote = FALSE, row.names = FALSE, col.names = FALSE)
    
    test <- read.csv(paste("input", ".csv", sep=""), header = TRUE)
    
    Output <- data.frame(Prediction=predict(model,test), round(predict(model,test,type="prob"), 3))
    print(Output)
    
  })
  
  # Status/Output Text Box
  output$contents <- renderPrint({
    if (input$submitbutton>0) { 
      isolate("Calculation complete.") 
    } else {
      return("Server is ready for calculation.")
    }
  })
  
  # Prediction results table
  output$tabledata <- renderTable({
    if (input$submitbutton>0) { 
      isolate(datasetInput()) 
    } 
  })
  
}

####################################
# Create the shiny app             #
####################################
shinyApp(ui = ui, server = server)


#library(shiny)
#runApp()
#deployApp()
