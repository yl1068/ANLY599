#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: yiranliu
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
## Seaborn builds on top of matplotlib
import seaborn as sns
sns.set(style="darkgrid")


rc={'font.size': 16, 'axes.labelsize': 16, 'legend.fontsize': 16.0, 
    'axes.titlesize': 16, 'xtick.labelsize': 16, 'ytick.labelsize': 16}

sns.set(rc=rc)



MyFileName="/Users/yiranliu/Desktop/Cleaned_SummerStudentAdmissions.csv"
StudentDF=pd.read_csv(MyFileName)
print(StudentDF.head())

#Gender 0 = Male, Gender 1 = Female
StudentDF.loc[StudentDF.Gender == 1, 'Gender'] = "Female"
StudentDF.loc[StudentDF.Gender == 0, 'Gender'] = "Male"
print(StudentDF.head())

#######################Gender and admission##############################
plot=sns.catplot(y="Decision", hue="Gender", kind="count",
            palette="pastel", edgecolor=".6",
            data=StudentDF)
plot.fig.subplots_adjust(top=0.9) # adjust the Figure in rp
plot.fig.suptitle('Decisison by Gender')





## Create percentages from data
Counts=StudentDF.groupby(["Gender","Decision"])["GPA"].count()/StudentDF.groupby(["Gender"])["GPA"].count()

print(Counts)
Counts.unstack().plot.bar(stacked=True)

your_list = [['Female',15/43, 13/43, 15/43],['Male',12/34,10/34,12/34]]
df = pd.DataFrame (your_list,columns=['Gender','Admit','Waitlist','Decline'])
print(df)




# plot a Stacked Bar Chart using matplotlib 
plot=df.plot( 
  x = 'Gender',  
  kind = 'barh',  
  stacked = True,  
  title = 'Decision Rate by Gender',  
  mark_right = True) 
  
df_total = df["Admit"] + df["Waitlist"] + df["Decline"] 
df_rel = df[df.columns[1:]]*100
  
for n in df_rel: 
    for i, (cs, ab, pc) in enumerate(zip(df.iloc[:, 1:].cumsum(1)[n],  
                                         df[n], df_rel[n])): 
        plt.text(cs - ab / 2, i, str(np.round(pc, 1)) + '%',  
                 va = 'center', ha = 'center')
plot.legend(bbox_to_anchor=(1.05, 1), loc='upper left')










# ViolinPlot = sns.violinplot(x="Gender", 
#                             y="GPA", 
#                             hue="Decision", 
#                             data=StudentDF).set_title("GPA and Decision by Gender")





# # Create labels
# labels=StudentDF.Decision.unique()
# print(labels)

# ## Create percentages from data
# Counts=StudentDF.groupby("Decision")["GPA"].count()
# print(Counts)
# print(Counts[labels[0]])  ## Here, we are getting the count for 
# ## label[0] which is "Admit

# ## num of rows
# (R,C)=StudentDF.shape
# print(R)
# ## Create the fractions
# F1=np.round(Counts[labels[0]]/R,3)
# print(F1)
# F2=np.round(Counts[labels[1]]/R,3)
# F3=np.round(Counts[labels[2]]/R,3)
# ## These are the pie fractions we BUILT!
# fracs = [F1, F2, F3]

# ## Get means
# m1,m2,m3=StudentDF.groupby("Decision")["GPA"].mean()
# print(m3)
# ## Make labels include the means
# labels[0]=str(labels[0])
# labels[1]=str(labels[1])
# labels[2]=str(labels[2])


# # Shift the second slice using explode
# fig, axs = plt.subplots(1, 1)
# axs.pie(fracs, labels=labels, autopct='%1.1f%%', shadow=True,
#               explode=(0.1, 0, 0))
# plt.title('Admission Decisions')


#####Female students
# Create labels
is_female =  StudentDF['Gender']=='Female'
StudentDF_female = StudentDF[is_female]
labels=StudentDF_female.Decision.unique()
print(labels)

## Create percentages from data
Counts=StudentDF_female.groupby("Decision")["GPA"].count()
print(Counts)
print(Counts[labels[0]])  ## Here, we are getting the count for 
## label[0] which is "Admit

## num of rows
(R,C)=StudentDF_female.shape
print(R)
## Create the fractions
F1=np.round(Counts[labels[0]]/R,3)
print(F1)
F2=np.round(Counts[labels[1]]/R,3)
F3=np.round(Counts[labels[2]]/R,3)
## These are the pie fractions we BUILT!
fracs = [F1, F2, F3]

## Get means
m1,m2,m3=StudentDF_female.groupby("Decision")["GPA"].mean()
print(m3)
## Make labels include the means
labels[0]=str(labels[0])
labels[1]=str(labels[1])
labels[2]=str(labels[2])


# Shift the second slice using explode
fig, axs = plt.subplots(1, 1)
axs.pie(fracs, labels=labels, autopct='%1.1f%%', shadow=True,
              explode=(0.1, 0, 0))
plt.title('Admission Decisions for Female Students')



#####Male students
# Create labels
is_male =  StudentDF['Gender']=='Male'
StudentDF_male = StudentDF[is_male]
labels=StudentDF_male.Decision.unique()
print(labels)

## Create percentages from data
Counts=StudentDF_male.groupby("Decision")["GPA"].count()
print(Counts)
print(Counts[labels[0]])  ## Here, we are getting the count for 
## label[0] which is "Admit

## num of rows
(R,C)=StudentDF_male.shape
print(R)
## Create the fractions
F1=np.round(Counts[labels[0]]/R,3)
print(F1)
F2=np.round(Counts[labels[1]]/R,3)
F3=np.round(Counts[labels[2]]/R,3)
## These are the pie fractions we BUILT!
fracs = [F1, F2, F3]

## Get means
m1,m2,m3=StudentDF_male.groupby("Decision")["GPA"].mean()
print(m3)
## Make labels include the means
labels[0]=str(labels[0])
labels[1]=str(labels[1])
labels[2]=str(labels[2])


# Shift the second slice using explode
fig, axs = plt.subplots(1, 1)
axs.pie(fracs, labels=labels, autopct='%1.1f%%', shadow=True,
              explode=(0.1, 0, 0))
plt.title('Admission Decisions for Male Students')





################work experience and admission##############################
fig = plt.subplots(figsize=(10, 10), sharex=False)
## If sharex is true then all x axes will be the same
sns.distplot(StudentDF["WorkExp"] , color="olive")
plt.title('Student Work Experience')



sns.displot(StudentDF, x="WorkExp", hue="Decision", kind="kde", fill=True)
plt.title('Student Work Experience by Decision')


# sns.lmplot("GPA", "WorkExp", data=StudentDF, hue="Decision", 
#                          fit_reg=False, col='Decision', col_wrap=3)


pkmn_type_colors = ['#6890F0',  # Water                   
                    '#F08030',  # Fire
                    '#78C850',  # Grass
                   ]
## Choose  to include the regression line
sns.lmplot(x='GPA', y='WorkExp',data=StudentDF,
           fit_reg=True, # No regression line
           hue='Decision',
           palette=pkmn_type_colors)   # Color by Decision
plt.title('GPA vs Work Experience by Decision')



################state and admission##############################
plot=sns.catplot(y="State", kind="count", data=StudentDF,palette="Spectral",
            order = StudentDF['State'].value_counts().index)
plot.fig.subplots_adjust(top=0.9) 
plot.fig.suptitle('States of Students')


# plot=sns.catplot(y="State", hue="Decision", kind="count",col="State",col_wrap=1,
#             palette="pastel",
#             data=StudentDF)
# plot.fig.subplots_adjust(top=0.9) 
# plot.fig.suptitle('Decisison by State')



sns.catplot(y="State", col="Decision", col_wrap=3,
                data=StudentDF,palette="pastel",
                order = StudentDF['State'].value_counts().index,
                kind="count", height=5)

sns.set(style="darkgrid")
sns.swarmplot(x="GPA", y="State", hue="Decision",data=StudentDF)
plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
plt.title("Decision and GPA by State")




################volunteer and admission##############################
fig = plt.subplots(figsize=(10, 10), sharex=False)
## If sharex is true then all x axes will be the same


plot=sns.distplot( StudentDF["VolunteerLevel"], color="teal")
plt.title("Volunteer Level of Students")

pkmn_type_colors = ['#6890F0',  # Water                   
                    '#F08030',  # Fire
                    '#78C850',  # Grass
                   ]
## Choose  to include the regression line
sns.lmplot(x='GPA', y='VolunteerLevel',data=StudentDF,
           fit_reg=True, # No regression line
           hue='Decision',
           palette=pkmn_type_colors)   # Color by Decision
plt.title('GPA vs Volunteer Level by Decision')




pkmn_type_colors = ['#6890F0',  # Water                   
                    '#F08030',  # Fire
                    '#78C850',  # Grass
                   ]
## Choose  to include the regression line
sns.lmplot(x='WorkExp', y='VolunteerLevel',data=StudentDF,
           fit_reg=True, # No regression line
           hue='Decision',
           palette=pkmn_type_colors)   # Color by Decision
plt.title('GPA vs Volunteer Level by Decision')




#Heat map
MyCor=StudentDF.corr()
print(MyCor)
sns.heatmap(MyCor, xticklabels=MyCor.columns, 
            yticklabels=MyCor.columns, annot=True,
            cmap=sns.diverging_palette(220, 20, as_cmap=True))




################Decision Tree############################
# Load libraries
import pandas as pd
from sklearn.tree import DecisionTreeClassifier # Import Decision Tree Classifier
from sklearn.model_selection import train_test_split # Import train_test_split function
from sklearn import metrics #Import scikit-learn metrics module for accuracy calculation


MyFileName="/Users/yiranliu/Desktop/Cleaned_SummerStudentAdmissions.csv"
StudentDF=pd.read_csv(MyFileName)
print(StudentDF.head())




StudentTrainDF, StudentTestDF = train_test_split(StudentDF, test_size=0.3,random_state=1)


## Save labels
StudentTestLabels=StudentTestDF["Decision"]
#print(StudentTestLabels)
## remove labels
StudentTestDF = StudentTestDF.drop(["Decision"], axis=1)
#print(StudentTestDF)

## Set up the training data so the models get what they expect
StudentTrainDF_nolabels=StudentTrainDF.drop(["Decision"], axis=1)
#print(StudentTrainDF_nolabels)
StudentTrainLabels=StudentTrainDF["Decision"]

#StudentTrainDF_nolabels_quant=StudentTrainDF_nolabels.drop(["Gender"], axis=1)
StudentTrainDF_nolabels_quant=StudentTrainDF_nolabels.drop(["State"], axis=1)
#StudentTestDF_quant=StudentTestDF.drop(["Gender"], axis=1)
StudentTestDF_quant=StudentTestDF.drop(["State"], axis=1)

# Create Decision Tree classifer object
clf = DecisionTreeClassifier()

# Train Decision Tree Classifer
clf = clf.fit(StudentTrainDF_nolabels_quant,StudentTrainLabels)

#Predict the response for test dataset
y_pred = clf.predict(StudentTestDF_quant)


print("Accuracy:",metrics.accuracy_score(StudentTestLabels, y_pred))


from sklearn.tree import export_graphviz
from IPython.display import Image  
import pydotplus
from six import StringIO


dot_data = StringIO()
export_graphviz(clf, out_file=dot_data,  
                filled=True, rounded=True,
                special_characters=True,feature_names = ["GPA","WorkExp","TestScore","WritingScore","Gender","VolunteerLevel"]
                ,class_names=["Admit","Waitlist","Decline"])
graph = pydotplus.graph_from_dot_data(dot_data.getvalue())  
graph.write_png('diabetes.png')
Image(graph.create_png())

